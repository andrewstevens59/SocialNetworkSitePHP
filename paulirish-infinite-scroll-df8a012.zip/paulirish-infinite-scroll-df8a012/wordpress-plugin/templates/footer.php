<?php
/**
 * Template to include on wp_footer front-end; passes plugin options to javascript function
 * @package Infinite_Scroll
 */
?>
<script>jQuery( infinite_scroll.contentSelector ).infinitescroll( infinite_scroll );</script>
